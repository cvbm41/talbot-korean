// const globalUrl = "https://250204.aisystem64.org"
const globalUrl = "https://excaatch.asuscomm.com:8443"